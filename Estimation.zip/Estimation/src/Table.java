import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.Timer;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Table extends JPanel {
    private ArrayList<Card> deck;
    private Image background = null;
    private User user;
    private Computer computer1;
    private Computer computer2;
    private Computer computer3;

    public Table() {
        try {
            this.background = ImageIO.read(new File("Background/cardtable.jpeg"));
        } catch (IOException var2) {
            var2.printStackTrace();
        }

        String a = JOptionPane.showInputDialog("HELLO");
        deck = new ArrayList<>();
        createDeck();

        Player[] players = {user,computer1,computer2, computer3};
        for (int k = 0; k<players.length; k++){
            ArrayList<Card> hand = new ArrayList<>();
            for (int j = 0; j<13; j++){
                int ran = (int) (Math.random()*deck.size());
                hand.add(deck.remove(ran));
            }
            int estimate = 0;
            for (int i = 0; i<hand.size(); i++){
                if (hand.get(i).getValue()>10){
                    estimate++;
                }
            }

            if (k==0){
                user = new User(hand,estimate, "user");
                user.sortHand();
            }
            if (k==1){
                computer1 = new Computer(hand, estimate, "computer1");
            }
            if (k==2){
                computer2 = new Computer(hand, estimate,"computer2");
            }
            if (k==3){
                computer3 = new Computer(hand, estimate,"computer3");
            }

        }


        /*System.out.println();
        System.out.println(computer1.getEstimate());
        System.out.println();
        System.out.println(computer2.getEstimate());
        System.out.println();
        System.out.println(computer3.getEstimate());
        System.out.println(computer1.getHand());
        System.out.println(computer2.getHand());
        System.out.println(computer3.getHand());
        */
        this.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                System.out.println("X: "+x+ " Y: "+y);
                for (int i = user.hand.size()-1; i>=0; i--){
                    if (x < (user.hand.get(i).xPos + 35) && x >(user.hand.get(i).xPos)&& (y<(user.hand.get(i).yPos+61) && y>(user.hand.get(i).yPos))){
                        System.out.println("WORKS!");
                        user.hand.remove(i);
                        System.out.println(user.hand);
                        repaint();
                    }
                }
            }
        });

        /*Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                repaint();
            }
        });

        timer.start();
        */
        this.setFocusable(true);
    }


    public void paintComponent(Graphics g) {
        removeAll();
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        drawBackground(g2d);
        int increment = 0;
        for (Card card: user.getHand()){
            this.add(card.getImage());
            card.image.setBounds(80+increment, 400, 41, 61);
            card.changeXPos(80+increment);
            increment+=45;
        }

    }

    public void drawBackground(Graphics2D g2d) {
        if (background != null) g2d.drawImage(background, 0, 0, Game.WIDTH, Game.HEIGHT, null);
    }

    public void showMessage(String s, Graphics2D g2d) {
        Font font = new Font("SansSerif", Font.PLAIN, 40);
        Rectangle2D textBox = font.getStringBounds(s, g2d.getFontRenderContext());
        g2d.setFont(font);
        g2d.setColor(new Color(64, 64, 64, 128));
        g2d.drawString(s, (int) (Game.WIDTH / 2 - textBox.getWidth() / 2), 50);
    }

    public void createDeck(){
        String temp = null;
        for(int j = 0; j<4;j++){
            for (int i = 2; i<15; i++){
                if (j==0){
                    temp = "s";
                }
                else if(j==1){
                    temp = "d";
                }
                else if(j==2){
                    temp = "c";
                }
                else{
                    temp = "h";
                }
                deck.add(new Card(i,temp,false));

            }
        }


        for (Card card:deck){
            System.out.print(card);
        }

    }

    /*private void updateGame() {
        // System.out.println("Update game elements now...");
        Line2D leftBorder, rightBorder, topBorder, bottomBorder;
        leftBorder = new Line2D.Double(0, 0, 0, Breakout.HEIGHT);
        rightBorder = new Line2D.Double(Breakout.WIDTH, 0, Breakout.WIDTH, Breakout.HEIGHT);
        topBorder = new Line2D.Double(0, 0, Breakout.WIDTH, 0);
        bottomBorder = new Line2D.Double(0, Breakout.HEIGHT, Breakout.WIDTH, Breakout.HEIGHT);
        Rectangle2D proj = ball.project();
        if (proj.intersectsLine(leftBorder) || proj.intersectsLine(rightBorder)) ball.flipHorizontalSpeed();
        if (proj.intersectsLine(topBorder)) ball.flipVerticalSpeed();
        if (proj.intersectsLine(bottomBorder)) ball = new Ball();
        if (proj.intersects(paddle)) ball.flipVerticalSpeed();
        boolean brickFlipped = false; // may hit multiple bricks in one update -- only flip once!
        for (int i = 0; i<bricks.size(); i++) {
            if (bricks.get(i).intersects(proj)) {
                brickFlipped = true;
                bricks.remove(i);
                i--;
            }
        }
        if (brickFlipped) ball.flipVerticalSpeed();
        ball.update();
    }
     */

}