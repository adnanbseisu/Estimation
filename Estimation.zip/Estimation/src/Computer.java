import java.util.ArrayList;

public class Computer extends Player{
    public Computer(ArrayList<Card> hand, int estimate, String name) {
        super(hand, estimate, name);
    }

    @Override
    public Card playCard() {
        return null;
    }
}
