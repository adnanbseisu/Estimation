import javax.swing.*;
import javax.swing.JFrame;

public class Game extends JFrame {
        public static final int HEIGHT = 600;
        public static final int WIDTH = 800;

        public Game() {
            this.setSize(800, 600);
            this.setDefaultCloseOperation(3);
            this.setResizable(false);
            this.add(new Table());
        }

        public static void main(String[] args) {
            Game game = new Game();
            game.setVisible(true);
            System.out.println("Game has started. Close window when done.");
        }

    }